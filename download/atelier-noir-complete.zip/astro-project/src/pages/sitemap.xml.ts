---
// sitemap.xml.ts - Generated sitemap for SEO

const site = 'https://ateliernoir.com';

const pages = [
  {
    url: '/',
    lastmod: new Date().toISOString(),
    changefreq: 'weekly',
    priority: 1.0,
  },
  {
    url: '/#projects',
    lastmod: new Date().toISOString(),
    changefreq: 'weekly',
    priority: 0.9,
  },
  {
    url: '/#urunler',
    lastmod: new Date().toISOString(),
    changefreq: 'weekly',
    priority: 0.9,
  },
  {
    url: '/#metal-deck-klips',
    lastmod: new Date().toISOString(),
    changefreq: 'monthly',
    priority: 0.8,
  },
  {
    url: '/#plastik-deck-klips',
    lastmod: new Date().toISOString(),
    changefreq: 'monthly',
    priority: 0.8,
  },
  {
    url: '/#services',
    lastmod: new Date().toISOString(),
    changefreq: 'monthly',
    priority: 0.8,
  },
  {
    url: '/#about',
    lastmod: new Date().toISOString(),
    changefreq: 'monthly',
    priority: 0.7,
  },
  {
    url: '/#contact',
    lastmod: new Date().toISOString(),
    changefreq: 'monthly',
    priority: 0.7,
  },
];

const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
${pages.map(page => `  <url>
    <loc>${site}${page.url}</loc>
    <lastmod>${page.lastmod}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

return new Response(sitemap, {
  headers: {
    'Content-Type': 'application/xml',
    'Cache-Control': 'public, max-age=3600',
  },
});
---
