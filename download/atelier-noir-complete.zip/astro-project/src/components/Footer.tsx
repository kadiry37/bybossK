'use client';

import { motion } from 'framer-motion';
import { Instagram, Linkedin, Mail, MapPin, Phone, Palette } from 'lucide-react';
import { companyInfo } from '../data/seed';

const footerLinks = {
  company: [
    { name: 'Hakkımızda', href: '#about' },
    { name: 'Ekibimiz', href: '#team' },
    { name: 'Kariyer', href: '#careers' },
    { name: 'Blog', href: '#blog' },
  ],
  services: [
    { name: 'Mimari Tasarım', href: '#architecture' },
    { name: 'İç Mekan', href: '#interior' },
    { name: 'Mobilya', href: '#furniture' },
    { name: 'Danışmanlık', href: '#consulting' },
  ],
  legal: [
    { name: 'Gizlilik Politikası', href: '#privacy' },
    { name: 'Kullanım Şartları', href: '#terms' },
    { name: 'Çerez Politikası', href: '#cookies' },
  ],
};

export default function Footer() {
  const socialIcons = [
    { icon: Instagram, href: companyInfo.socialLinks.instagram, label: 'Instagram' },
    { icon: Linkedin, href: companyInfo.socialLinks.linkedin, label: 'LinkedIn' },
    { icon: Palette, href: companyInfo.socialLinks.pinterest, label: 'Pinterest' },
  ];

  return (
    <footer className="bg-noir-950 border-t border-noir-800 relative">
      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-px gold-line" />

      {/* Main Footer */}
      <div className="container mx-auto px-6 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <motion.a
              href="#hero"
              className="inline-block mb-6"
              whileHover={{ scale: 1.02 }}
            >
              <span className="font-serif text-3xl font-bold tracking-tight">
                <span className="text-white">ATELIER</span>{' '}
                <span className="gradient-text">NOIR</span>
              </span>
            </motion.a>

            <p className="text-noir-400 text-sm leading-relaxed mb-6 max-w-sm">
              {companyInfo.tagline}. Modern estetik ve zamansız tasarımın buluştuğu
              noktada, mekanlarınızı sanata dönüştürüyoruz.
            </p>

            {/* Contact Info */}
            <div className="space-y-3">
              <a
                href={`tel:${companyInfo.phone}`}
                className="flex items-center gap-3 text-noir-400 hover:text-gold-500 transition-colors text-sm"
              >
                <Phone size={16} className="text-gold-500" />
                {companyInfo.phone}
              </a>
              <a
                href={`mailto:${companyInfo.email}`}
                className="flex items-center gap-3 text-noir-400 hover:text-gold-500 transition-colors text-sm"
              >
                <Mail size={16} className="text-gold-500" />
                {companyInfo.email}
              </a>
              <div className="flex items-start gap-3 text-noir-400 text-sm">
                <MapPin size={16} className="text-gold-500 mt-1 flex-shrink-0" />
                {companyInfo.address}
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-4 mt-6">
              {socialIcons.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-noir-800 hover:bg-gold-500 flex items-center justify-center group transition-colors duration-300"
                  aria-label={social.label}
                >
                  <social.icon
                    size={18}
                    className="text-noir-400 group-hover:text-noir-900 transition-colors"
                  />
                </a>
              ))}
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-serif text-lg font-bold text-white mb-6">Şirket</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-noir-400 hover:text-gold-500 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services Links */}
          <div>
            <h4 className="font-serif text-lg font-bold text-white mb-6">
              Hizmetler
            </h4>
            <ul className="space-y-3">
              {footerLinks.services.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-noir-400 hover:text-gold-500 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="font-serif text-lg font-bold text-white mb-6">Yasal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-noir-400 hover:text-gold-500 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-noir-800">
        <div className="container mx-auto px-6 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-noir-500 text-sm">
              © {new Date().getFullYear()} {companyInfo.name}. Tüm hakları saklıdır.
            </p>
            <p className="text-noir-600 text-xs">
              İstanbul, Türkiye'de tasarlandı ve geliştirildi.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
