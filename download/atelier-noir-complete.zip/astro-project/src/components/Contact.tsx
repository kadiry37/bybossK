'use client';

import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';
import { companyInfo } from '../data/seed';

export default function Contact() {
  return (
    <section id="contact" className="py-24 lg:py-32 bg-noir-950 relative overflow-hidden">
      {/* Top gold line */}
      <div className="absolute top-0 left-0 right-0 h-px gold-line" />
      
      {/* Background decorations */}
      <div className="absolute top-1/3 -left-32 w-64 h-64 bg-gold-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 -right-32 w-64 h-64 bg-gold-500/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block px-4 py-2 border border-gold-500/30 text-gold-500 text-sm font-medium tracking-widest uppercase mb-6"
          >
            İletişim
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6"
          >
            Projenizi <span className="gradient-text">Konuşalım</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-noir-400 text-lg max-w-2xl mx-auto"
          >
            Hayalinizdeki mekanı gerçeğe dönüştürmek için ilk adımı atın. 
            Ücretsiz danışmanlık için bizimle iletişime geçin.
          </motion.p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left: Contact Info & Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            {/* Contact Cards */}
            <div className="grid sm:grid-cols-2 gap-4 mb-10">
              {/* Phone */}
              <a
                href={`tel:${companyInfo.phone.replace(/\s/g, '')}`}
                className="group p-6 bg-noir-900 border border-noir-800 hover:border-gold-500/50 transition-all duration-300"
              >
                <div className="w-12 h-12 bg-noir-800 group-hover:bg-gold-500 flex items-center justify-center mb-4 transition-colors">
                  <Phone className="w-5 h-5 text-gold-500 group-hover:text-noir-900 transition-colors" />
                </div>
                <h3 className="font-serif text-lg font-bold text-white mb-1">Telefon</h3>
                <p className="text-noir-400 text-sm">{companyInfo.phone}</p>
              </a>

              {/* Email */}
              <a
                href={`mailto:${companyInfo.email}`}
                className="group p-6 bg-noir-900 border border-noir-800 hover:border-gold-500/50 transition-all duration-300"
              >
                <div className="w-12 h-12 bg-noir-800 group-hover:bg-gold-500 flex items-center justify-center mb-4 transition-colors">
                  <Mail className="w-5 h-5 text-gold-500 group-hover:text-noir-900 transition-colors" />
                </div>
                <h3 className="font-serif text-lg font-bold text-white mb-1">E-posta</h3>
                <p className="text-noir-400 text-sm">{companyInfo.email}</p>
              </a>

              {/* Address */}
              <div className="group p-6 bg-noir-900 border border-noir-800 hover:border-gold-500/50 transition-all duration-300 sm:col-span-2">
                <div className="w-12 h-12 bg-noir-800 group-hover:bg-gold-500 flex items-center justify-center mb-4 transition-colors">
                  <MapPin className="w-5 h-5 text-gold-500 group-hover:text-noir-900 transition-colors" />
                </div>
                <h3 className="font-serif text-lg font-bold text-white mb-1">Adres</h3>
                <p className="text-noir-400 text-sm">{companyInfo.address}</p>
              </div>
            </div>

            {/* Working Hours */}
            <div className="flex items-center gap-4 p-4 bg-noir-900/50 border border-noir-800 mb-8">
              <Clock className="w-5 h-5 text-gold-500" />
              <div>
                <p className="text-white text-sm font-medium">Çalışma Saatleri</p>
                <p className="text-noir-400 text-sm">Pazartesi - Cuma: 09:00 - 18:00</p>
              </div>
            </div>

            {/* Quick Contact Form */}
            <div className="bg-noir-900 border border-noir-800 p-6 lg:p-8">
              <h3 className="font-serif text-xl font-bold text-white mb-6">Hızlı İletişim</h3>
              <form className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Adınız Soyadınız"
                    className="w-full bg-noir-800 border border-noir-700 text-white px-4 py-3 text-sm focus:border-gold-500 focus:outline-none transition-colors placeholder-noir-500"
                  />
                  <input
                    type="email"
                    placeholder="E-posta Adresiniz"
                    className="w-full bg-noir-800 border border-noir-700 text-white px-4 py-3 text-sm focus:border-gold-500 focus:outline-none transition-colors placeholder-noir-500"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Konu"
                  className="w-full bg-noir-800 border border-noir-700 text-white px-4 py-3 text-sm focus:border-gold-500 focus:outline-none transition-colors placeholder-noir-500"
                />
                <textarea
                  rows={4}
                  placeholder="Mesajınız"
                  className="w-full bg-noir-800 border border-noir-700 text-white px-4 py-3 text-sm focus:border-gold-500 focus:outline-none transition-colors placeholder-noir-500 resize-none"
                />
                <button
                  type="submit"
                  className="btn-premium w-full text-noir-900 font-semibold py-4 flex items-center justify-center gap-2 group"
                >
                  <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  Mesaj Gönder
                </button>
              </form>
            </div>
          </motion.div>

          {/* Right: 3D Map Cube */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative flex items-center justify-center lg:justify-end"
          >
            {/* 3D Map Cube Container */}
            <div className="relative w-full max-w-lg aspect-square">
              {/* Main Map Cube */}
              <div className="map-cube-wrapper w-full h-full relative">
                <div className="map-cube w-full h-full">
                  {/* Front - Map */}
                  <div className="map-cube-face front">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.0134721256456!2d29.01139!3d41.0771!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDA0JzM3LjYiTiAyOcKwMDAnNDEuMCJF!5e0!3m2!1str!2str!4v1234567890"
                      className="w-full h-full grayscale contrast-125 opacity-80"
                      style={{ filter: 'grayscale(100%) contrast(1.2)' }}
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-noir-900/80 via-transparent to-noir-900/30 pointer-events-none" />
                    {/* Location pin */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                      <div className="w-8 h-8 bg-gold-500 rounded-full flex items-center justify-center animate-pulse">
                        <MapPin className="w-4 h-4 text-noir-900" />
                      </div>
                    </div>
                  </div>

                  {/* Back - Pattern */}
                  <div className="map-cube-face back bg-noir-800">
                    <div 
                      className="w-full h-full"
                      style={{
                        backgroundImage: `radial-gradient(circle at 2px 2px, rgba(201,169,98,0.3) 1px, transparent 0)`,
                        backgroundSize: '20px 20px'
                      }}
                    />
                  </div>

                  {/* Right - Info */}
                  <div className="map-cube-face right bg-noir-900 flex items-center justify-center p-8">
                    <div className="text-center">
                      <div className="text-6xl font-serif font-bold gradient-text mb-2">25+</div>
                      <div className="text-noir-400 text-sm">Yıllık Deneyim</div>
                    </div>
                  </div>

                  {/* Left - Pattern */}
                  <div className="map-cube-face left bg-noir-800">
                    <div 
                      className="w-full h-full"
                      style={{
                        backgroundImage: `linear-gradient(45deg, rgba(201,169,98,0.1) 25%, transparent 25%, transparent 75%, rgba(201,169,98,0.1) 75%, rgba(201,169,98,0.1)), linear-gradient(45deg, rgba(201,169,98,0.1) 25%, transparent 25%, transparent 75%, rgba(201,169,98,0.1) 75%, rgba(201,169,98,0.1))`,
                        backgroundSize: '40px 40px',
                        backgroundPosition: '0 0, 20px 20px'
                      }}
                    />
                  </div>

                  {/* Top - Gold accent */}
                  <div className="map-cube-face top bg-gradient-to-br from-gold-500/30 to-noir-800">
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="font-serif text-4xl font-bold text-gold-500/50">AN</span>
                    </div>
                  </div>

                  {/* Bottom - Dark */}
                  <div className="map-cube-face bottom bg-noir-900" />
                </div>

                {/* Glow effect */}
                <div className="absolute inset-0 bg-gold-500/10 blur-[80px] -z-10" />
              </div>

              {/* Decorative elements */}
              <div className="absolute -bottom-6 -right-6 w-24 h-24 border border-gold-500/20" />
              <div className="absolute -top-6 -left-6 w-20 h-20 border border-gold-500/10" />
            </div>
          </motion.div>
        </div>
      </div>

      {/* CSS for 3D Map Cube */}
      <style>{`
        .map-cube-wrapper {
          perspective: 1000px;
          perspective-origin: 50% 50%;
        }
        
        .map-cube {
          transform-style: preserve-3d;
          animation: mapCubeRotate 40s linear infinite;
        }
        
        .map-cube-face {
          position: absolute;
          width: 100%;
          height: 100%;
          backface-visibility: visible;
          border: 2px solid rgba(201, 169, 98, 0.3);
          overflow: hidden;
        }
        
        .map-cube-face.front { transform: translateZ(50%); }
        .map-cube-face.back { transform: rotateY(180deg) translateZ(50%); }
        .map-cube-face.right { transform: rotateY(90deg) translateZ(50%); }
        .map-cube-face.left { transform: rotateY(-90deg) translateZ(50%); }
        .map-cube-face.top { transform: rotateX(90deg) translateZ(50%); }
        .map-cube-face.bottom { transform: rotateX(-90deg) translateZ(50%); }
        
        @keyframes mapCubeRotate {
          0% { transform: rotateX(-10deg) rotateY(0deg); }
          100% { transform: rotateX(-10deg) rotateY(360deg); }
        }
      `}</style>
    </section>
  );
}
