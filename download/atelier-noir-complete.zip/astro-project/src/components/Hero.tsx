'use client';

import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { heroData } from '../data/seed';

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.4, 0, 0.2, 1],
      },
    },
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden bg-noir-900"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-noir-900 via-noir-800 to-noir-900" />

      {/* Animated gradient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl animate-float" />
      <div
        className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gold-500/5 rounded-full blur-3xl animate-float"
        style={{ animationDelay: '2s' }}
      />

      {/* Gold line accent */}
      <div className="absolute top-0 left-0 right-0 h-px gold-line" />

      <div className="container mx-auto px-6 py-32 lg:py-0 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center min-h-screen">
          {/* Text Content */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="text-center lg:text-left"
          >
            <motion.div variants={itemVariants} className="mb-6">
              <span className="inline-block px-4 py-2 border border-gold-500/30 text-gold-500 text-sm font-medium tracking-widest uppercase">
                Premium Tasarım Stüdyosu
              </span>
            </motion.div>

            <motion.h1
              variants={itemVariants}
              className="font-serif text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-8"
            >
              <span className="text-white">{heroData.title.split(' ')[0]}</span>
              <br />
              <span className="gradient-text">
                {heroData.title.split(' ').slice(1).join(' ')}
              </span>
            </motion.h1>

            <motion.p
              variants={itemVariants}
              className="text-noir-400 text-lg md:text-xl leading-relaxed mb-10 max-w-xl mx-auto lg:mx-0"
            >
              {heroData.subtitle}
            </motion.p>

            <motion.div
              variants={itemVariants}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <button className="btn-premium text-noir-900 font-semibold px-8 py-4 text-lg flex items-center justify-center gap-2 group">
                {heroData.buttonText}
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border border-noir-600 text-white hover:bg-noir-800 px-8 py-4 text-lg transition-colors">
                Videoyu İzle
              </button>
            </motion.div>

            {/* Stats */}
            <motion.div
              variants={itemVariants}
              className="flex justify-center lg:justify-start gap-12 mt-16"
            >
              <div>
                <div className="text-4xl md:text-5xl font-serif font-bold gradient-text">
                  150+
                </div>
                <div className="text-noir-500 text-sm mt-1">Tamamlanan Proje</div>
              </div>
              <div>
                <div className="text-4xl md:text-5xl font-serif font-bold gradient-text">
                  25+
                </div>
                <div className="text-noir-500 text-sm mt-1">Yıllık Deneyim</div>
              </div>
              <div>
                <div className="text-4xl md:text-5xl font-serif font-bold gradient-text">
                  40+
                </div>
                <div className="text-noir-500 text-sm mt-1">Ödül</div>
              </div>
            </motion.div>
          </motion.div>

          {/* 3D Cube - Banner Mode */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
            className="relative flex items-center justify-center"
          >
            {/* Cube wrapper with enhanced 3D perspective */}
            <div className="cube-banner-container w-80 h-80 md:w-[450px] md:h-[450px] relative">
              {/* Main rotating cube */}
              <div className="cube-3d w-full h-full">
                {/* Front face */}
                <div className="cube-face-3d front">
                  <img
                    src={heroData.cubeImages[0]}
                    alt="Tasarım 1"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                </div>

                {/* Right face */}
                <div className="cube-face-3d right">
                  <img
                    src={heroData.cubeImages[1]}
                    alt="Tasarım 2"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                </div>

                {/* Back face */}
                <div className="cube-face-3d back">
                  <img
                    src={heroData.cubeImages[2]}
                    alt="Tasarım 3"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                </div>

                {/* Left face */}
                <div className="cube-face-3d left">
                  <img
                    src={heroData.cubeImages[0]}
                    alt="Tasarım 1"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                </div>

                {/* Top face */}
                <div className="cube-face-3d top">
                  <img
                    src={heroData.cubeImages[1]}
                    alt="Tasarım 2"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                </div>

                {/* Bottom face */}
                <div className="cube-face-3d bottom">
                  <img
                    src={heroData.cubeImages[2]}
                    alt="Tasarım 3"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                </div>
              </div>

              {/* Enhanced glow effects */}
              <div className="absolute inset-0 bg-gold-500/10 blur-[100px] -z-10" />
              <div className="absolute inset-0 bg-gold-500/5 blur-[60px] -z-5" />
              
              {/* Shadow reflection */}
              <div className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-3/4 h-20 bg-gold-500/10 blur-3xl rounded-full" />
            </div>

            {/* Decorative frame elements */}
            <div className="absolute -bottom-12 -right-12 w-40 h-40 border border-gold-500/15" />
            <div className="absolute -top-12 -left-12 w-32 h-32 border border-gold-500/10" />
            <div className="absolute top-1/2 -right-20 w-1 h-24 bg-gradient-to-b from-gold-500/30 to-transparent" />
            <div className="absolute top-1/2 -left-20 w-1 h-24 bg-gradient-to-b from-gold-500/30 to-transparent" />
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 border-2 border-noir-600 rounded-full flex justify-center pt-2"
        >
          <div className="w-1.5 h-1.5 bg-gold-500 rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  );
}
