/**
 * ATELIER NOIR - API Client
 * PHP Backend ile iletişim için
 */

// API Base URL - Production'da PHP backend, Development'ta local data
const API_BASE_URL = import.meta.env.PROD 
  ? (import.meta.env.API_URL || '/api')
  : '/api';

/**
 * Generic fetch wrapper with error handling
 */
async function apiFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  } catch (error) {
    console.error(`API Fetch Error [${endpoint}]:`, error);
    throw error;
  }
}

/**
 * Hero Section Data
 */
export async function getHero() {
  return apiFetch<HeroData>('/hero.php');
}

/**
 * Projects
 */
export async function getProjects(category?: string, featured?: boolean) {
  const params = new URLSearchParams();
  if (category) params.append('category', category);
  if (featured) params.append('featured', 'true');
  
  const query = params.toString() ? `?${params.toString()}` : '';
  return apiFetch<ProjectData[]>(`/projects.php${query}`);
}

export async function getProject(slug: string) {
  return apiFetch<ProjectData>(`/projects.php?id=${slug}`);
}

/**
 * Services
 */
export async function getServices() {
  return apiFetch<ServiceData[]>(`/services.php`);
}

export async function getService(slug: string) {
  return apiFetch<ServiceData>(`/services.php?id=${slug}`);
}

/**
 * Products (Deck Klips)
 */
export async function getProducts(category?: string) {
  const params = category ? `?category=${category}` : '';
  return apiFetch<ProductData[]>(`/products.php${params}`);
}

export async function getProduct(slug: string) {
  return apiFetch<ProductData>(`/products.php?id=${slug}`);
}

/**
 * Site Settings
 */
export async function getSettings() {
  return apiFetch<SiteSettings>(`/settings.php`);
}

/**
 * Contact Form
 */
export async function submitContact(data: ContactFormData) {
  return apiFetch<{ success: boolean; message: string }>(`/contact.php`, {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

// ============================================
// TYPES
// ============================================

export interface HeroData {
  id: string;
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
  cubeImages: [string, string, string];
  stats: {
    projects: string;
    years: string;
    awards: string;
  };
}

export interface ProjectData {
  id: number;
  name: string;
  slug: string;
  category: 'architecture' | 'furniture';
  mainImage: string;
  galleryImages: string[];
  description: string;
  year: number;
  location: string;
  featured: boolean;
}

export interface ServiceData {
  id: number;
  name: string;
  slug: string;
  icon: string;
  shortDescription: string;
  longDescription: string;
}

export interface ProductData {
  id: number;
  name: string;
  slug: string;
  category: 'metal-deck-klips' | 'plastik-deck-klips';
  mainImage: string;
  galleryImages: string[];
  shortDescription: string;
  longDescription: string;
  specifications: string;
  specificationsArray: string[];
  price: number | null;
}

export interface SiteSettings {
  name: string;
  tagline: string;
  email: string;
  phone: string;
  address: string;
  socialLinks: {
    instagram: string;
    linkedin: string;
    pinterest: string;
    behance: string;
  };
}

export interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  subject?: string;
  message: string;
}
