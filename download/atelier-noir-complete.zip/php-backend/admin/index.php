<?php
/**
 * ATELIER NOIR - Simple Admin Panel
 * Single-file admin for quick edits
 * 
 * NOTE: For production, use a proper admin panel with authentication!
 */

session_start();

// ============================================
// AUTHENTICATION
// ============================================
$ADMIN_USER = 'admin';
$ADMIN_PASS = 'admin123'; // CHANGE THIS IN PRODUCTION!

function isLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function login($user, $pass) {
    global $ADMIN_USER, $ADMIN_PASS;
    if ($user === $ADMIN_USER && $pass === $ADMIN_PASS) {
        $_SESSION['admin_logged_in'] = true;
        return true;
    }
    return false;
}

function logout() {
    session_destroy();
    header('Location: ?action=login');
    exit;
}

// Handle login
if (isset($_POST['login'])) {
    if (login($_POST['username'], $_POST['password'])) {
        header('Location: ?');
        exit;
    } else {
        $error = 'Hatalı kullanıcı adı veya şifre!';
    }
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    logout();
}

// Require config
require_once __DIR__ . '/api/config.php';

// ============================================
// ACTIONS
// ============================================
$message = '';

// Get database connection
$db = Database::getInstance()->getConnection();

// Handle form submissions
if (isLoggedIn() && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_setting':
            $key = $_POST['setting_key'] ?? '';
            $value = $_POST['setting_value'] ?? '';
            if ($key) {
                $stmt = $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
                $stmt->execute([$value, $key]);
                $message = 'Ayar güncellendi!';
            }
            break;
            
        case 'add_project':
            $name = $_POST['name'] ?? '';
            $slug = create_slug($name);
            $category = $_POST['category'] ?? 'architecture';
            $description = $_POST['description'] ?? '';
            $year = (int)($_POST['year'] ?? date('Y'));
            $location = $_POST['location'] ?? '';
            $featured = isset($_POST['featured']) ? 1 : 0;
            $mainImage = $_POST['main_image'] ?? '';
            
            $stmt = $db->prepare("INSERT INTO projects (name, slug, category, main_image, description, year, location, featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $slug, $category, $mainImage, $description, $year, $location, $featured]);
            $message = 'Proje eklendi!';
            break;
            
        case 'delete_project':
            $id = (int)($_POST['id'] ?? 0);
            if ($id) {
                $stmt = $db->prepare("DELETE FROM projects WHERE id = ?");
                $stmt->execute([$id]);
                $message = 'Proje silindi!';
            }
            break;
    }
}

// ============================================
// DATA
// ============================================
$settings = $db->query("SELECT * FROM settings ORDER BY setting_key")->fetchAll(PDO::FETCH_KEY_PAIR);
$projects = $db->query("SELECT * FROM projects ORDER BY sort_order, created_at DESC")->fetchAll();
$services = $db->query("SELECT * FROM services ORDER BY sort_order")->fetchAll();
$products = $db->query("SELECT * FROM products ORDER BY sort_order")->fetchAll();
$contacts = $db->query("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 10")->fetchAll();

// ============================================
// PAGE
// ============================================
$page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - ATELIER NOIR</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .sidebar { min-height: 100vh; }
        .sidebar a { display: block; padding: 0.75rem 1rem; color: #a0aec0; text-decoration: none; }
        .sidebar a:hover, .sidebar a.active { background: #2d3748; color: #fff; }
        .card { background: #1a202c; border-radius: 0.5rem; padding: 1.5rem; margin-bottom: 1rem; }
        input, textarea, select { background: #2d3748; border: 1px solid #4a5568; color: #fff; padding: 0.5rem; width: 100%; border-radius: 0.25rem; }
        input:focus, textarea:focus, select:focus { outline: none; border-color: #c9a962; }
        label { color: #a0aec0; font-size: 0.875rem; margin-bottom: 0.25rem; display: block; }
        .btn { padding: 0.5rem 1rem; border-radius: 0.25rem; cursor: pointer; font-weight: 500; }
        .btn-gold { background: linear-gradient(135deg, #c9a962, #9a7633); color: #0a0a0a; }
        .btn-red { background: #e53e3e; color: #fff; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.75rem; text-align: left; border-bottom: 1px solid #2d3748; }
        th { color: #a0aec0; font-weight: 500; }
        td { color: #e2e8f0; }
    </style>
</head>
<body class="bg-gray-900 text-gray-100">
    <?php if (!isLoggedIn()): ?>
        <!-- LOGIN -->
        <div class="min-h-screen flex items-center justify-center">
            <div class="card w-full max-w-md">
                <h1 class="text-2xl font-bold mb-6 text-center">ATELIER NOIR Admin</h1>
                <?php if (isset($error)): ?>
                    <div class="bg-red-500 text-white p-3 rounded mb-4"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="mb-4">
                        <label>Kullanıcı Adı</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="mb-6">
                        <label>Şifre</label>
                        <input type="password" name="password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-gold w-full">Giriş Yap</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <!-- DASHBOARD -->
        <div class="flex">
            <!-- Sidebar -->
            <div class="sidebar w-64 bg-gray-800 flex-shrink-0">
                <div class="p-4 border-b border-gray-700">
                    <h1 class="text-xl font-bold">ATELIER NOIR</h1>
                    <p class="text-gray-400 text-sm">Admin Panel</p>
                </div>
                <nav>
                    <a href="?page=dashboard" class="<?php echo $page === 'dashboard' ? 'active' : ''; ?>">📊 Dashboard</a>
                    <a href="?page=settings" class="<?php echo $page === 'settings' ? 'active' : ''; ?>">⚙️ Site Ayarları</a>
                    <a href="?page=projects" class="<?php echo $page === 'projects' ? 'active' : ''; ?>">🏗️ Projeler</a>
                    <a href="?page=services" class="<?php echo $page === 'services' ? 'active' : '';;">📋 Hizmetler</a>
                    <a href="?page=products" class="<?php echo $page === 'products' ? 'active' : ''; ?>">🛒 Ürünler</a>
                    <a href="?page=contacts" class="<?php echo $page === 'contacts' ? 'active' : ''; ?>">📧 Mesajlar</a>
                    <a href="?action=logout" class="text-red-400 hover:text-red-300">🚪 Çıkış Yap</a>
                </nav>
            </div>
            
            <!-- Content -->
            <div class="flex-1 p-6">
                <?php if ($message): ?>
                    <div class="bg-green-500 text-white p-3 rounded mb-4"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php switch ($page):
                    case 'dashboard': ?>
                        <h2 class="text-2xl font-bold mb-6">Dashboard</h2>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                            <div class="card">
                                <div class="text-3xl font-bold text-yellow-500"><?php echo count($projects); ?></div>
                                <div class="text-gray-400">Proje</div>
                            </div>
                            <div class="card">
                                <div class="text-3xl font-bold text-yellow-500"><?php echo count($services); ?></div>
                                <div class="text-gray-400">Hizmet</div>
                            </div>
                            <div class="card">
                                <div class="text-3xl font-bold text-yellow-500"><?php echo count($products); ?></div>
                                <div class="text-gray-400">Ürün</div>
                            </div>
                            <div class="card">
                                <div class="text-3xl font-bold text-yellow-500"><?php echo count($contacts); ?></div>
                                <div class="text-gray-400">Mesaj</div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <h3 class="text-lg font-bold mb-4">Son Mesajlar</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Ad</th>
                                        <th>E-posta</th>
                                        <th>Konu</th>
                                        <th>Tarih</th>
                                        <th>Durum</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($contacts as $contact): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($contact['name']); ?></td>
                                        <td><?php echo htmlspecialchars($contact['email']); ?></td>
                                        <td><?php echo htmlspecialchars($contact['subject']); ?></td>
                                        <td><?php echo $contact['created_at']; ?></td>
                                        <td><span class="px-2 py-1 rounded text-xs <?php echo $contact['status'] === 'new' ? 'bg-blue-500' : 'bg-gray-500'; ?>"><?php echo $contact['status']; ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php break; ?>
                        
                    <?php case 'settings': ?>
                        <h2 class="text-2xl font-bold mb-6">Site Ayarları</h2>
                        <div class="card">
                            <form method="POST">
                                <input type="hidden" name="action" value="update_setting">
                                <div class="mb-4">
                                    <label>Site Adı</label>
                                    <input type="text" name="setting_value" value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>">
                                    <input type="hidden" name="setting_key" value="site_name">
                                </div>
                                <button type="submit" class="btn btn-gold">Kaydet</button>
                            </form>
                        </div>
                        
                        <div class="card">
                            <h3 class="text-lg font-bold mb-4">Hero Ayarları</h3>
                            <form method="POST">
                                <input type="hidden" name="action" value="update_setting">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label>Başlık</label>
                                        <input type="text" name="setting_value" value="<?php echo htmlspecialchars($settings['hero_title'] ?? ''); ?>">
                                        <input type="hidden" name="setting_key" value="hero_title">
                                    </div>
                                    <div>
                                        <label>Alt Başlık</label>
                                        <textarea name="setting_value" rows="3"><?php echo htmlspecialchars($settings['hero_subtitle'] ?? ''); ?></textarea>
                                        <input type="hidden" name="setting_key" value="hero_subtitle">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-gold mt-4">Kaydet</button>
                            </form>
                        </div>
                        <?php break; ?>
                        
                    <?php case 'projects': ?>
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-2xl font-bold">Projeler</h2>
                            <button onclick="toggleForm()" class="btn btn-gold">+ Yeni Proje</button>
                        </div>
                        
                        <div id="addForm" class="card hidden">
                            <h3 class="text-lg font-bold mb-4">Yeni Proje Ekle</h3>
                            <form method="POST">
                                <input type="hidden" name="action" value="add_project">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label>Proje Adı</label>
                                        <input type="text" name="name" required>
                                    </div>
                                    <div>
                                        <label>Kategori</label>
                                        <select name="category">
                                            <option value="architecture">Mimari</option>
                                            <option value="furniture">Mobilya</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Yıl</label>
                                        <input type="number" name="year" value="<?php echo date('Y'); ?>">
                                    </div>
                                    <div>
                                        <label>Konum</label>
                                        <input type="text" name="location">
                                    </div>
                                    <div class="col-span-2">
                                        <label>Görsel URL</label>
                                        <input type="text" name="main_image">
                                    </div>
                                    <div class="col-span-2">
                                        <label>Açıklama</label>
                                        <textarea name="description" rows="3"></textarea>
                                    </div>
                                    <div class="col-span-2">
                                        <label class="flex items-center">
                                            <input type="checkbox" name="featured" class="w-auto mr-2">
                                            Öne Çıkan
                                        </label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-gold mt-4">Ekle</button>
                            </form>
                        </div>
                        
                        <div class="card">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Görsel</th>
                                        <th>Ad</th>
                                        <th>Kategori</th>
                                        <th>Yıl</th>
                                        <th>Öne Çıkan</th>
                                        <th>İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($projects as $project): ?>
                                    <tr>
                                        <td><img src="<?php echo htmlspecialchars($project['main_image']); ?>" class="w-16 h-12 object-cover rounded"></td>
                                        <td><?php echo htmlspecialchars($project['name']); ?></td>
                                        <td><?php echo $project['category'] === 'architecture' ? 'Mimari' : 'Mobilya'; ?></td>
                                        <td><?php echo $project['year']; ?></td>
                                        <td><?php echo $project['featured'] ? '⭐' : '-'; ?></td>
                                        <td>
                                            <form method="POST" class="inline">
                                                <input type="hidden" name="action" value="delete_project">
                                                <input type="hidden" name="id" value="<?php echo $project['id']; ?>">
                                                <button type="submit" class="btn btn-red text-sm" onclick="return confirm('Silmek istediğinize emin misiniz?')">Sil</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php break; ?>
                        
                    <?php default: ?>
                        <p>Bu sayfa henüz hazır değil.</p>
                <?php endswitch; ?>
            </div>
        </div>
        
        <script>
            function toggleForm() {
                document.getElementById('addForm').classList.toggle('hidden');
            }
        </script>
    <?php endif; ?>
</body>
</html>
