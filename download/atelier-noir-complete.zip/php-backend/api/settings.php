<?php
/**
 * ATELIER NOIR - Site Settings API
 * Endpoint: /api/settings.php
 */

require_once __DIR__ . '/config.php';

// CORS headers
set_cors_headers();

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Sadece GET izin ver
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Tüm ayarları getir
    $stmt = $db->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Formatlanmış site bilgileri
    $siteInfo = [
        'name' => $settings['site_name'] ?? 'ATELIER NOIR',
        'tagline' => $settings['site_tagline'] ?? '',
        'email' => $settings['site_email'] ?? '',
        'phone' => $settings['site_phone'] ?? '',
        'address' => $settings['site_address'] ?? '',
        'socialLinks' => [
            'instagram' => $settings['social_instagram'] ?? '',
            'linkedin' => $settings['social_linkedin'] ?? '',
            'pinterest' => $settings['social_pinterest'] ?? '',
            'behance' => $settings['social_behance'] ?? ''
        ]
    ];
    
    // Cache header (1 saat)
    header('Cache-Control: public, max-age=3600');
    
    json_response($siteInfo);
    
} catch (Exception $e) {
    error_log("Settings API Error: " . $e->getMessage());
    json_error('Sunucu hatası', 500);
}
