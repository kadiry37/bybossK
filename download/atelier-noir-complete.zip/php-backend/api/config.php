<?php
/**
 * ATELIER NOIR - Database Configuration
 * 
 * Bu dosyayı hosting'inize yükledikten sonra,
 * veritabanı bilgilerinizi güncelleyin.
 */

// ============================================
// VERİTABANI AYARLARI
// ============================================
// DirectAdmin'den bu bilgileri alabilirsiniz:
// Veritabanları > Veritabanı Oluştur

define('DB_HOST', 'localhost');        // Genelde localhost
define('DB_NAME', 'atelier_noir');     // Veritabanı adı
define('DB_USER', 'db_user');          // Veritabanı kullanıcı adı
define('DB_PASS', 'db_password');      // Veritabanı şifresi
define('DB_CHARSET', 'utf8mb4');

// ============================================
// SITE AYARLARI
// ============================================
define('SITE_URL', 'https://yourdomain.com');
define('SITE_NAME', 'ATELIER NOIR');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');

// ============================================
// GÜVENLİK AYARLARI
// ============================================
define('API_KEY', 'your-secret-api-key-here');  // API erişimi için
define('ADMIN_SESSION_NAME', 'atelier_admin');

// ============================================
// CORS AYARLARI (Astro frontend için)
// ============================================
define('ALLOWED_ORIGINS', [
    'http://localhost:4321',
    'http://localhost:3000',
    'https://yourdomain.com',
    'https://www.yourdomain.com'
]);

// ============================================
// VERİTABANI BAĞLANTISI
// ============================================
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Production'da log'a yaz, detaylı hata verme
            error_log("Database Connection Error: " . $e->getMessage());
            throw new Exception("Veritabanı bağlantı hatası");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    // Prevent cloning
    private function __clone() {}
    
    // Prevent unserialization
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * JSON Response gönder
 */
function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Hata response
 */
function json_error($message, $status = 400) {
    json_response(['error' => $message], $status);
}

/**
 * CORS headers ekle
 */
function set_cors_headers() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    
    if (in_array($origin, ALLOWED_ORIGINS)) {
        header("Access-Control-Allow-Origin: $origin");
    } else {
        header("Access-Control-Allow-Origin: " . ALLOWED_ORIGINS[0]);
    }
    
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key");
    header("Access-Control-Allow-Credentials: true");
}

/**
 * API Key kontrolü
 */
function validate_api_key() {
    $headers = getallheaders();
    $apiKey = $headers['X-API-Key'] ?? $headers['x-api-key'] ?? '';
    
    // GET request'ler için API key zorunlu değil (public data)
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        return true;
    }
    
    // POST, PUT, DELETE için API key gerekli
    if ($apiKey !== API_KEY) {
        json_error('Unauthorized - Invalid API Key', 401);
    }
    
    return true;
}

/**
 * Input temizle
 */
function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Slug oluştur
 */
function create_slug($text) {
    $text = mb_strtolower($text, 'UTF-8');
    $text = str_replace(
        ['ç', 'ğ', 'ı', 'ö', 'ş', 'ü', ' '],
        ['c', 'g', 'i', 'o', 's', 'u', '-'],
        $text
    );
    $text = preg_replace('/[^a-z0-9-]/', '', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}

/**
 * Upload klasörünü kontrol et
 */
function ensure_upload_dir() {
    if (!is_dir(UPLOAD_PATH)) {
        mkdir(UPLOAD_PATH, 0755, true);
    }
    return UPLOAD_PATH;
}
