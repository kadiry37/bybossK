<?php
/**
 * ATELIER NOIR - Hero API
 * Endpoint: /api/hero.php
 */

require_once __DIR__ . '/config.php';

// CORS headers
set_cors_headers();

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Sadece GET izin ver
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Tüm site ayarlarını getir
    $stmt = $db->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Hero data formatla
    $hero = [
        'id' => 'hero-001',
        'title' => $settings['hero_title'] ?? 'Mimarlıkta Mükemmellik',
        'subtitle' => $settings['hero_subtitle'] ?? '',
        'buttonText' => $settings['hero_button_text'] ?? 'Keşfet',
        'buttonLink' => $settings['hero_button_link'] ?? '#projects',
        'cubeImages' => [
            $settings['hero_cube_image_1'] ?? 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
            $settings['hero_cube_image_2'] ?? 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
            $settings['hero_cube_image_3'] ?? 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800&q=80'
        ],
        'stats' => [
            'projects' => $settings['stats_projects'] ?? '150',
            'years' => $settings['stats_years'] ?? '25',
            'awards' => $settings['stats_awards'] ?? '40'
        ]
    ];
    
    // Cache header (1 saat)
    header('Cache-Control: public, max-age=3600');
    
    json_response($hero);
    
} catch (Exception $e) {
    error_log("Hero API Error: " . $e->getMessage());
    json_error('Sunucu hatası', 500);
}
