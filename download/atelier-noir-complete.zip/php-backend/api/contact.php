<?php
/**
 * ATELIER NOIR - Contact Form API
 * Endpoint: /api/contact.php
 */

require_once __DIR__ . '/config.php';

// CORS headers
set_cors_headers();

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Sadece POST izin ver
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // JSON input al
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        // Form data olarak dene
        $input = $_POST;
    }
    
    // Gerekli alanları kontrol et
    $required = ['name', 'email', 'message'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            json_error("$field alanı zorunludur", 400);
        }
    }
    
    // Email validasyonu
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        json_error('Geçerli bir e-posta adresi girin', 400);
    }
    
    // Verileri temizle
    $name = sanitize_input($input['name']);
    $email = sanitize_input($input['email']);
    $phone = sanitize_input($input['phone'] ?? '');
    $subject = sanitize_input($input['subject'] ?? 'İletişim Formu');
    $message = sanitize_input($input['message']);
    
    // Veritabanına kaydet
    $stmt = $db->prepare("
        INSERT INTO contacts (name, email, phone, subject, message, status)
        VALUES (?, ?, ?, ?, ?, 'new')
    ");
    
    $stmt->execute([$name, $email, $phone, $subject, $message]);
    $contactId = $db->lastInsertId();
    
    // Email gönder (opsiyonel)
    $to = 'info@ateliernoir.com'; // Site email adresi
    $emailSubject = "[ATELIER NOIR] $subject";
    $emailBody = "
Yeni İletişim Formu Mesajı
==========================

Ad: $name
E-posta: $email
Telefon: $phone
Konu: $subject

Mesaj:
$message

---
Bu mesaj website üzerinden gönderilmiştir.
    ";
    
    $headers = [
        'From: noreply@ateliernoir.com',
        'Reply-To: ' . $email,
        'Content-Type: text/plain; charset=UTF-8'
    ];
    
    // Production'da email gönder
    // mail($to, $emailSubject, $emailBody, implode("\r\n", $headers));
    
    json_response([
        'success' => true,
        'message' => 'Mesajınız başarıyla gönderildi. En kısa sürede size dönüş yapacağız.',
        'id' => $contactId
    ]);
    
} catch (Exception $e) {
    error_log("Contact API Error: " . $e->getMessage());
    json_error('Mesaj gönderilirken bir hata oluştu. Lütfen tekrar deneyin.', 500);
}
