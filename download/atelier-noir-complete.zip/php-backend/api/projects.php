<?php
/**
 * ATELIER NOIR - Projects API
 * Endpoint: /api/projects.php
 * 
 * GET: Tüm projeleri veya filtrelenmiş projeleri getir
 * GET ?id=slug: Tek proje getir
 */

require_once __DIR__ . '/config.php';

// CORS headers
set_cors_headers();

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Sadece GET izin ver
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Tek proje getir
    if (isset($_GET['id'])) {
        $slug = sanitize_input($_GET['id']);
        $stmt = $db->prepare("
            SELECT * FROM projects 
            WHERE slug = ? AND status = 'active'
        ");
        $stmt->execute([$slug]);
        $project = $stmt->fetch();
        
        if (!$project) {
            json_error('Proje bulunamadı', 404);
        }
        
        // Gallery images'ı array'e çevir
        $project['galleryImages'] = $project['gallery_images'] 
            ? explode(',', $project['gallery_images']) 
            : [];
        unset($project['gallery_images']);
        
        json_response($project);
    }
    
    // Filtre parametreleri
    $category = isset($_GET['category']) ? sanitize_input($_GET['category']) : null;
    $featured = isset($_GET['featured']) && $_GET['featured'] === 'true';
    
    // SQL sorgusu oluştur
    $sql = "SELECT * FROM projects WHERE status = 'active'";
    $params = [];
    
    if ($category && in_array($category, ['architecture', 'furniture'])) {
        $sql .= " AND category = ?";
        $params[] = $category;
    }
    
    if ($featured) {
        $sql .= " AND featured = 1";
    }
    
    $sql .= " ORDER BY sort_order ASC, created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $projects = $stmt->fetchAll();
    
    // Her proje için gallery images'ı array'e çevir
    foreach ($projects as &$project) {
        $project['galleryImages'] = $project['gallery_images'] 
            ? explode(',', $project['gallery_images']) 
            : [];
        unset($project['gallery_images']);
        
        // Frontend uyumluluğu için
        $project['featured'] = (bool) $project['featured'];
    }
    
    // Cache header (1 saat)
    header('Cache-Control: public, max-age=3600');
    
    json_response($projects);
    
} catch (Exception $e) {
    error_log("Projects API Error: " . $e->getMessage());
    json_error('Sunucu hatası', 500);
}
