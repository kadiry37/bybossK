<?php
/**
 * ATELIER NOIR - Products API (Deck Klips)
 * Endpoint: /api/products.php
 */

require_once __DIR__ . '/config.php';

// CORS headers
set_cors_headers();

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Sadece GET izin ver
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Tek ürün getir
    if (isset($_GET['id'])) {
        $slug = sanitize_input($_GET['id']);
        $stmt = $db->prepare("
            SELECT * FROM products 
            WHERE slug = ? AND status = 'active'
        ");
        $stmt->execute([$slug]);
        $product = $stmt->fetch();
        
        if (!$product) {
            json_error('Ürün bulunamadı', 404);
        }
        
        // Gallery images'ı array'e çevir
        $product['galleryImages'] = $product['gallery_images'] 
            ? explode(',', $product['gallery_images']) 
            : [];
        unset($product['gallery_images']);
        
        // Specifications'ı array'e çevir
        $product['specificationsArray'] = $product['specifications']
            ? explode("\n", $product['specifications'])
            : [];
        
        json_response($product);
    }
    
    // Filtre parametreleri
    $category = isset($_GET['category']) ? sanitize_input($_GET['category']) : null;
    
    // SQL sorgusu oluştur
    $sql = "SELECT * FROM products WHERE status = 'active'";
    $params = [];
    
    if ($category && in_array($category, ['metal-deck-klips', 'plastik-deck-klips'])) {
        $sql .= " AND category = ?";
        $params[] = $category;
    }
    
    $sql .= " ORDER BY sort_order ASC, created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
    
    // Her ürün için formatting
    foreach ($products as &$product) {
        $product['galleryImages'] = $product['gallery_images'] 
            ? explode(',', $product['gallery_images']) 
            : [];
        unset($product['gallery_images']);
        
        // Specifications'ı array'e çevir
        $product['specificationsArray'] = $product['specifications']
            ? explode("\n", $product['specifications'])
            : [];
    }
    
    // Cache header (1 saat)
    header('Cache-Control: public, max-age=3600');
    
    json_response($products);
    
} catch (Exception $e) {
    error_log("Products API Error: " . $e->getMessage());
    json_error('Sunucu hatası', 500);
}
