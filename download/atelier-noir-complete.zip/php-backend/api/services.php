<?php
/**
 * ATELIER NOIR - Services API
 * Endpoint: /api/services.php
 */

require_once __DIR__ . '/config.php';

// CORS headers
set_cors_headers();

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Sadece GET izin ver
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Tek hizmet getir
    if (isset($_GET['id'])) {
        $slug = sanitize_input($_GET['id']);
        $stmt = $db->prepare("
            SELECT * FROM services 
            WHERE slug = ? AND status = 'active'
        ");
        $stmt->execute([$slug]);
        $service = $stmt->fetch();
        
        if (!$service) {
            json_error('Hizmet bulunamadı', 404);
        }
        
        json_response($service);
    }
    
    // Tüm hizmetleri getir
    $stmt = $db->query("
        SELECT * FROM services 
        WHERE status = 'active' 
        ORDER BY sort_order ASC
    ");
    $services = $stmt->fetchAll();
    
    // Cache header (1 saat)
    header('Cache-Control: public, max-age=3600');
    
    json_response($services);
    
} catch (Exception $e) {
    error_log("Services API Error: " . $e->getMessage());
    json_error('Sunucu hatası', 500);
}
