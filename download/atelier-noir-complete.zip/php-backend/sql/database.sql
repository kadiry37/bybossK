-- ============================================
-- ATELIER NOIR - Database Schema & Seed Data
-- MySQL 5.7+ Compatible
-- ============================================

-- Veritabanı oluştur (eğer yoksa)
CREATE DATABASE IF NOT EXISTS atelier_noir
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE atelier_noir;

-- ============================================
-- TABLOLAR
-- ============================================

-- 1. Site Ayarları (Hero, vs.)
DROP TABLE IF EXISTS settings;
CREATE TABLE settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Projeler
DROP TABLE IF EXISTS projects;
CREATE TABLE projects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    category ENUM('architecture', 'furniture') NOT NULL DEFAULT 'architecture',
    main_image VARCHAR(500) NOT NULL,
    gallery_images TEXT,
    description TEXT,
    year INT,
    location VARCHAR(255),
    featured BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'draft') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Hizmetler
DROP TABLE IF EXISTS services;
CREATE TABLE services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    icon VARCHAR(100) DEFAULT 'Building2',
    short_description VARCHAR(500),
    long_description TEXT,
    status ENUM('active', 'draft') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Ürünler (Deck Klips)
DROP TABLE IF EXISTS products;
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    category ENUM('metal-deck-klips', 'plastik-deck-klips') NOT NULL,
    main_image VARCHAR(500),
    gallery_images TEXT,
    short_description VARCHAR(500),
    long_description TEXT,
    specifications TEXT,
    price DECIMAL(10, 2) DEFAULT NULL,
    status ENUM('active', 'draft') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. İletişim Formları
DROP TABLE IF EXISTS contacts;
CREATE TABLE contacts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    subject VARCHAR(255),
    message TEXT,
    status ENUM('new', 'read', 'replied') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Admin Kullanıcıları
DROP TABLE IF EXISTS admin_users;
CREATE TABLE admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    role ENUM('admin', 'editor') DEFAULT 'editor',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SEED DATA
-- ============================================

-- Site Ayarları
INSERT INTO settings (setting_key, setting_value) VALUES
('site_name', 'ATELIER NOIR'),
('site_tagline', 'Where Vision Meets Architecture'),
('site_email', 'info@ateliernoir.com'),
('site_phone', '+90 212 555 0123'),
('site_address', 'Levent Mahallesi, Büyükdere Caddesi No:123, Şişli, İstanbul, Türkiye'),
('hero_title', 'Mimarlıkta Mükemmellik'),
('hero_subtitle', 'Modern estetik ve zamansız tasarımın buluştuğu noktada, mekanlarınızı sanata dönüştürüyoruz. Her proje, benzersiz bir hikayenin başlangıcıdır.'),
('hero_button_text', 'Projelerimizi Keşfedin'),
('hero_button_link', '#projects'),
('hero_cube_image_1', 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80'),
('hero_cube_image_2', 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80'),
('hero_cube_image_3', 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800&q=80'),
('social_instagram', 'https://instagram.com/ateliernoir'),
('social_linkedin', 'https://linkedin.com/company/ateliernoir'),
('social_pinterest', 'https://pinterest.com/ateliernoir'),
('social_behance', 'https://behance.net/ateliernoir'),
('stats_projects', '150'),
('stats_years', '25'),
('stats_awards', '40');

-- Projeler
INSERT INTO projects (name, slug, category, main_image, gallery_images, description, year, location, featured, status, sort_order) VALUES
('Bosphorus Azure Residence', 'bosphorus-azure-residence', 'architecture', 
 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80',
 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80,https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80,https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
 'İstanbul Boğazı''nın eşsiz manzarasına sahip, modern minimalizm ve lüks konforun buluştuğu 8 villa projesi. Cam cephe sistemleri ve doğal taş dokusuyla çevreyle uyumlu bir tasarım.',
 2024, 'İstanbul, Türkiye', TRUE, 'active', 1),

('Nebula Corporate Tower', 'nebula-corporate-tower', 'architecture',
 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&q=80',
 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80,https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80,https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800&q=80',
 '45 katlı ofis kulesi, sürdürülebilir mimari ilkelerine uygun tasarlanmış LEED Platinum sertifikalı yapı. Akıllı bina teknolojileri ve esnek çalışma alanları.',
 2023, 'Ankara, Türkiye', TRUE, 'active', 2),

('Sapphire Beach Villa', 'sapphire-beach-villa', 'architecture',
 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1200&q=80',
 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80,https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&q=80,https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&q=80',
 'Akdeniz kıyısında 1200m² müstakil villa. Sonsuzluk havuzu, özel marina ve akıllı ev otomasyonu. Doğal malzemeler ve yerel mimari dokuya saygı gösteren tasarım.',
 2024, 'Bodrum, Türkiye', FALSE, 'active', 3),

('Aurora Kolleksiyonu', 'aurora-kolleksiyonu', 'furniture',
 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=1200&q=80',
 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80,https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=800&q=80,https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&q=80',
 'El işçiliği ile üretilmiş özel tasarım koltuk takımı. İtalyan deri, ceviz ağacı iskelet ve el dökümü pirinç detaylar. Limited edition 50 adet ile sınırlı koleksiyon.',
 2024, 'Milano, İtalya', TRUE, 'active', 4),

('Zenith Yemek Masası', 'zenith-yemek-masasi', 'furniture',
 'https://images.unsplash.com/photo-1617806118233-18e1de247200?w=1200&q=80',
 'https://images.unsplash.com/photo-1617806118233-18e1de247200?w=800&q=80,https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=800&q=80,https://images.unsplash.com/photo-1611269154421-4e27233ac5c7?w=800&q=80',
 'Tek parça mermer masa üstü ve pirinç kaplama metal ayaklardan oluşan heykelsi yemek masası. 12 kişilik kapasite, her parça benzersiz doğal desenlere sahip.',
 2023, 'İstanbul, Türkiye', FALSE, 'active', 5);

-- Hizmetler
INSERT INTO services (name, slug, icon, short_description, long_description, status, sort_order) VALUES
('Mimari Tasarım', 'mimari-tasarim', 'Building2',
 'Konseptten teslimata kapsamlı mimari çözümler',
 'Fikrinizden yola çıkarak, mekanın potansiyelini en üst düzeye çıkaran özgün mimari tasarımlar sunuyoruz. Konsept geliştirme, proje yönetimi ve uygulama sürecinin tamamında yanınızdayız. Her projede çevresel sürdürülebilirlik ve estetik mükemmellik önceliğimizdir.',
 'active', 1),

('İç Mekan Tasarımı', 'ic-mekan-tasarimi', 'Home',
 'Mekanlarınıza karakter katan iç mimari',
 'Yaşam ve çalışma alanlarınızı kişiliğinizi yansıtan özel mekanlara dönüştürüyoruz. Malzeme seçimi, renk paleti, mobilya düzenlemesi ve aydınlatma tasarımı ile fonksiyonel ve estetik iç mekanlar yaratıyoruz. Her detay özenle tasarlanır.',
 'active', 2),

('Özel Mobilya', 'ozel-mobilya', 'Armchair',
 'Benzersiz el yapımı mobilya koleksiyonları',
 'Atölyemizde, en kaliteli malzemelerle el işçiliği kullanarak size özel mobilyalar üretiyoruz. Klasikten moderne, minimalistten ekletik tarzlara kadar geniş bir yelpazede tasarım imkanı sunuyoruz. Her parça, mekanınıza özel ölçülerde üretilir.',
 'active', 3),

('Danışmanlık', 'danismanlik', 'MessageSquare',
 'Uzman görüşleri ile doğru kararlar',
 'Yatırımınızı değerlendirmeden önce profesyonel danışmanlık hizmetimizden faydalanın. Arsa analizi, fiyatlandırma, proje değerlendirmesi ve pazar araştırması konularında uzman ekibimiz size rehberlik eder. Doğru karar için doğru bilgiyle hareket edin.',
 'active', 4);

-- Ürünler (Deck Klips)
INSERT INTO products (name, slug, category, main_image, short_description, long_description, specifications, status, sort_order) VALUES
('Metal Deck Klips Pro', 'metal-deck-klips-pro', 'metal-deck-klips',
 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
 'Profesyonel deck montajı için paslanmaz çelik klips',
 'Paslanmaz çelikten üretilen Metal Deck Klips Pro, exterior deck uygulamalarında uzun ömürlü ve güvenli montaj sağlar. Tüm hava koşullarına dayanıklı, korozyona karşı üstün koruma.',
 'Malzeme: 316 Paslanmaz Çelik\nBoyut: 50mm x 25mm\nKalınlık: 2mm\nPaket: 100 Adet/Kutu\nGaranti: 10 Yıl',
 'active', 1),

('Metal Deck Klips Ekonomik', 'metal-deck-klips-ekonomik', 'metal-deck-klips',
 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
 'Bütçe dostu galvaniz metal deck klips',
 'Galvaniz kaplamalı metal klips, standart deck uygulamaları için ekonomik çözüm. Kolay montaj ve güvenli tutuş sağlar.',
 'Malzeme: Galvaniz Çelik\nBoyut: 45mm x 22mm\nKalınlık: 1.5mm\nPaket: 200 Adet/Kutu\nGaranti: 5 Yıl',
 'active', 2),

('Plastik Deck Klips Standart', 'plastik-deck-klips-standart', 'plastik-deck-klips',
 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
 'UV dayanımlı plastik deck klips',
 'Yüksek kaliteli UV stabilize polimerden üretilmiş, güneş ışınlarına karşı dayanıklı plastik deck klips. Hafif ve kolay montaj imkanı sunar.',
 'Malzeme: UV Stabilize Polimer\nBoyut: 40mm x 20mm\nRenk: Siyah / Kahverengi\nPaket: 250 Adet/Kutu\nGaranti: 3 Yıl',
 'active', 3),

('Plastik Deck Klips Premium', 'plastik-deck-klips-premium', 'plastik-deck-klips',
 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
 'Geliştirilmiş tasarım ile premium plastik klips',
 'Geliştirilmiş kanca sistemi ve takviyeli gövde yapısı ile üstün tutuş performansı. Kompozit deck uygulamaları için ideal çözüm.',
 'Malzeme: Takviyeli Polimer\nBoyut: 48mm x 24mm\nRenk: Siyah / Kahverengi / Gri\nPaket: 200 Adet/Kutu\nGaranti: 5 Yıl',
 'active', 4);

-- Admin Kullanıcısı (şifre: admin123)
-- NOT: Production'da bu şifreyi değiştirin!
INSERT INTO admin_users (username, password, email, name, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@ateliernoir.com', 'Administrator', 'admin');

-- ============================================
-- INDEX'LER
-- ============================================
CREATE INDEX idx_projects_category ON projects(category);
CREATE INDEX idx_projects_featured ON projects(featured);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_services_status ON services(status);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_contacts_status ON contacts(status);
